﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Generators
{
    class GenerateUserName
    {

        string username;
        string firstName;
        string lastName;

        public GenerateUserName(string username, string firstName, string lastName)
        {
            this.username = username;
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public GenerateUserName()
        {

        }

        public string Generate(string firstName, string lastName)
        {
            string username = "";

            // declare random number
            Random rnd = new Random();

            // Get the first letter of the first name
            username += firstName.Substring(0, 1);

            // Add the LastName
            username += lastName;

            if(username.Length < 8)
            {
                username += rnd.Next(1000, 9999);
            } else
            {
                username = username.Substring(0, (username.Length + 6) - username.Length);
                username += rnd.Next(1000, 9999);
            }

            return username;
        }

        // Getters and Setters
        public string Username { get => username; set => username = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
    }
}
