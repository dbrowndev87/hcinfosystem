﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Generators
{
    class GenerateStudentID
    {
        int studentId;

        public GenerateStudentID()
        {
            this.studentId = GenerateID();
        }

        public int GenerateID()
        {
            int id;

            // declare random number
            Random rnd = new Random();

            // get the date
            string date = DateTime.Now.ToString("yyyy/mm/dd");

            // isolate the last two numbers of the date.
            date = date.Substring(2, 2);

            // concatinate the random numbers
            date += rnd.Next(1000, 9999);

            id = Convert.ToInt32(date);

            return id;
        }

        public int Student_Id { get => studentId; set => studentId = value; }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
