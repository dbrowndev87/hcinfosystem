﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Generators
{
    class GenerateTransID
    {
        int trans_id = 0;

        public GenerateTransID()
        {
            this.trans_id = GenerateID();
        }

        public int GenerateID()
        {
            Random rnd = new Random();
            return rnd.Next(100000000, 999999999);
        }

        public int Trans_id { get => trans_id; set => trans_id = value; }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
